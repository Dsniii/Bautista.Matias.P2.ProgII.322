
package model;

import java.io.Serializable;
import service.CSVSerializable;

public class Criatura implements Comparable<Criatura>, CSVSerializable, Serializable{
    
    private int id;
    private String nombre;
    private String origen;
    private TipoCriatura tipo;

    public Criatura(int id, String nombre, String origen, TipoCriatura tipo) {
        this.id = id;
        this.nombre = nombre;
        this.origen = origen;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getOrigen() {
        return origen;
    }

    public TipoCriatura getTipo() {
        return tipo;
    }

    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + origen + "," + tipo;
    }

    public static Criatura fromCSV(String linea) {
        String[] p = linea.split(",");
        return new Criatura(Integer.parseInt(p[0]),p[1],p[2],TipoCriatura.valueOf(p[3])
        );
    }

    @Override
    public String toString() {
        return id + " - " + nombre + " - " + origen + " - " + tipo;
    }
    
    
}
