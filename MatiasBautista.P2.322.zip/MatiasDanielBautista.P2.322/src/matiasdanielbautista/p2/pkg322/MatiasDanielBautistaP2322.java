
package matiasdanielbautista.p2.pkg322;


import model.Criatura;
import model.TipoCriatura;
import persistence.BestiarioUpsideDown;
import config.Rutas;
import java.io.IOException;

public class MatiasDanielBautistaP2322 {

    
    public static void main(String[] args) {
        
        try {

            BestiarioUpsideDown<Criatura> bestiario = new BestiarioUpsideDown<>();

            bestiario.agregar(new Criatura(1, "Demogorgon", "Upside Down", TipoCriatura.DEMOGORGON));
            bestiario.agregar(new Criatura(2, "Demodog Juvenil", "Bosque de Hawkins", TipoCriatura.DEMODOG));
            bestiario.agregar(new Criatura(3, "Shadow Tendril", "Dimensión Principal", TipoCriatura.SHADOW_MONSTER));
            bestiario.agregar(new Criatura(4, "Mind Flayer Spawn", "Upside Down", TipoCriatura.MIND_FLAYER_MINION));
            bestiario.agregar(new Criatura(5, "Murciélago del Upside Down", "Cueva Oscura", TipoCriatura.MURCIELAGO));

            System.out.println("Criaturas:");
            bestiario.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCriaturas tipo DEMODOG:");
            bestiario.filtrar(c -> ((Criatura)c).getTipo() == TipoCriatura.DEMODOG)
                     .forEach(c -> System.out.println(c));

            System.out.println("\nCriaturas que contienen 'shadow':");
            bestiario.filtrar(c -> ((Criatura)c).getNombre().toLowerCase().contains("shadow"))
                     .forEach(c -> System.out.println(c));

            System.out.println("\nCriaturas ordenadas por ID:");
            bestiario.ordenar();
            bestiario.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCriaturas ordenadas por nombre:");
            bestiario.ordenar((a, b) -> ((Criatura)a).getNombre()
                    .compareToIgnoreCase(((Criatura)b).getNombre()));
            bestiario.paraCadaElemento(c -> System.out.println(c));

            bestiario.guardarEnArchivo(Rutas.BINARIO);

            BestiarioUpsideDown<Criatura> cargado = new BestiarioUpsideDown<>();
            cargado.cargarDesdeArchivo(Rutas.BINARIO);

            System.out.println("\nCriaturas cargadas desde archivo binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));

            bestiario.guardarEnCSV(Rutas.CSV);

            cargado.cargarDesdeCSV(Rutas.CSV, Criatura::fromCSV);

            System.out.println("\nCriaturas cargadas desde archivo CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        
        
    }
    
}
