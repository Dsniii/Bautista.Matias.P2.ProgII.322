package config;

public class Rutas {
    public static final String BINARIO = "src/resource/criaturas.dat";
    public static final String CSV = "src/resource/criaturas.csv";
}
