
package persistence;


import service.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.function.Predicate;
import java.util.function.Consumer;
import java.util.function.Function;


public class BestiarioUpsideDown <T extends CSVSerializable & Serializable & Comparable<T>> {
    
    private List<T> criaturas = new ArrayList<>();

    public void agregar(T c) {
        criaturas.add(c);
    }

    public T obtener(int index) {
        return criaturas.get(index);
    }

    public void eliminar(int index) {
        criaturas.remove(index);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T c : criaturas) {
            if (criterio.test(c)) resultado.add(c);
        }
        return resultado;
    }

    public void ordenar() {
        Collections.sort(criaturas);
    }

    public void ordenar(Comparator<T> comp) {
        criaturas.sort(comp);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T c : criaturas) {
            accion.accept(c);
        }
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        File f = new File(ruta);
        f.getParentFile().mkdirs();

        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
        oos.writeObject(criaturas);
        oos.close();
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta));
        criaturas = (List<T>) ois.readObject();
        ois.close();
    }

    public void guardarEnCSV(String ruta) throws IOException {
        File f = new File(ruta);
        f.getParentFile().mkdirs();

        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        for (T c : criaturas) {
            bw.write(c.toCSV());
            bw.newLine();
        }
        bw.close();
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> mapper) throws IOException {
        criaturas.clear();
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        String linea;
        while ((linea = br.readLine()) != null) {
            criaturas.add(mapper.apply(linea));
        }
        br.close();
    }
}

    
    

